<meta charset="utf-8">
<meta content="width=device-width, initial-scale=1.0" name="viewport">
<meta content="" name="description">
<meta content="" name="keywords">

<?php echo $__env->yieldContent('meta'); ?><?php /**PATH C:\xampp\htdocs\cypherocean\resources\views/front/layout/meta.blade.php ENDPATH**/ ?>