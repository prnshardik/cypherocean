<link href="<?php echo e(asset('back/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('back/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('back/vendors/themify-icons/css/themify-icons.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('back/vendors/jvectormap/jquery-jvectormap-2.0.3.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('back/css/main.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('back/vendors/DataTables/datatables.min.css')); ?>" rel="stylesheet" />
<link href="<?php echo e(asset('back/vendors/toastr/toastr.min.css')); ?>" rel="stylesheet" />

<style> .error{ color:red; } </style>

<?php echo $__env->yieldContent('styles'); ?>
<?php /**PATH C:\xampp\htdocs\cypherocean\resources\views/back/layout/styles.blade.php ENDPATH**/ ?>