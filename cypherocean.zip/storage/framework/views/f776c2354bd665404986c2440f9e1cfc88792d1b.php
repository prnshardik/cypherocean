<script src="<?php echo e(asset('back/vendors/jquery/dist/jquery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/vendors/popper.js/dist/umd/popper.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/vendors/metisMenu/dist/metisMenu.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/vendors/jquery-slimscroll/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/vendors/chart.js/dist/Chart.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/vendors/jvectormap/jquery-jvectormap-2.0.3.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/vendors/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/vendors/jvectormap/jquery-jvectormap-us-aea-en.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/js/app.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('back/vendors/DataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('back/vendors/toastr/toastr.min.js')); ?>" type="text/javascript"></script>

<script>
    <?php
        $success = '';
        if(\Session::has('success'))
            $success = \Session::get('success');

        $error = '';
        if(\Session::has('error'))
            $error = \Session::get('error');
    ?>

    var success = "<?php echo e($success); ?>";
    var error = "<?php echo e($error); ?>";

    if(success != ''){ toastr.success(success, 'Success'); }

    if(error != ''){ toastr.error(error, 'error'); }
</script>

<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH C:\xampp\htdocs\cypherocean\resources\views/back/layout/scripts.blade.php ENDPATH**/ ?>