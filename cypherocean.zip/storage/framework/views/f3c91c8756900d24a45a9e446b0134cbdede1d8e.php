<footer class="page-footer">
    <div class="font-13"><?php echo e(date('Y')); ?> © <b><?php echo e(_site_title()); ?></b> - All rights reserved.</div>
    <div class="to-top"><i class="fa fa-angle-double-up"></i></div>
</footer><?php /**PATH C:\xampp\htdocs\cypherocean\resources\views/back/layout/footer.blade.php ENDPATH**/ ?>