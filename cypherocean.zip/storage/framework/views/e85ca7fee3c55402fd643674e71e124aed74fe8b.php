<header class="header">
    <div class="page-brand">
        <a class="link" href="<?php echo e(route('admin.home')); ?>">
            <span class="brand"><?php echo e(_site_title()); ?>

            </span>
            <span class="brand-mini"><?php echo e(_site_title_sf()); ?></span>
        </a>
    </div>
    <div class="flexbox flex-1">
        <ul class="nav navbar-toolbar">
            <li>
                <a class="nav-link sidebar-toggler js-sidebar-toggler"><i class="ti-menu"></i></a>
            </li>
            
        </ul>
        <ul class="nav navbar-toolbar">
            
            <li class="dropdown dropdown-user">
                <a class="nav-link dropdown-toggle link" data-toggle="dropdown">
                    <img src="<?php echo e(url('back/uploads/users').'/'.auth()->user()->image); ?>" />
                    <span></span><?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?><i class="fa fa-angle-down m-l-5"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-right">
                    <a class="dropdown-item" href="profile.html"><i class="fa fa-user"></i>Profile</a>
                    <a class="dropdown-item" href="profile.html"><i class="fa fa-cog"></i>Settings</a>
                    <a class="dropdown-item" href="javascript:;"><i class="fa fa-support"></i>Support</a>
                    <li class="dropdown-divider"></li>
                    <a class="dropdown-item" href="<?php echo e(route('admin.logout')); ?>"><i class="fa fa-power-off"></i>Logout</a>
                </ul>
            </li>
        </ul>
    </div>
</header><?php /**PATH C:\xampp\htdocs\cypherocean\resources\views/back/layout/header.blade.php ENDPATH**/ ?>