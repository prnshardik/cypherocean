<?php

    if (!function_exists('_site_title')) {
        function _site_title() {
            return 'CypherOcean';
        }
    }

    if (!function_exists('_site_title_sf')) {
        function _site_title_sf() {
            return 'CO';
        }
    }


?>
