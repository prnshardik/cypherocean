<?php
    // this is our event
    // We need to update it in the database
    $event = $_POST['event'];

    // but this is a test project so we return true
    return true;
?>